<?php

//security class - mouse trap